-- Database: TEMPLATE
-- Author: 
CREATE DATABASE template
    WITH OWNER = postgres
        ENCODING = 'UTF8'
        TABLESPACE = pg_default
        LC_COLLATE = 'undefined'
        LC_CTYPE = 'undefined'
        CONNECTION LIMIT = -1;